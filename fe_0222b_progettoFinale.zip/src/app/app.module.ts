import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { AuthRoutingModule } from './components/form/auth/auth-routing.module';
import { AuthGuard } from './components/form/auth/auth.guard';
import { AuthModule } from './components/form/auth/auth.module';
import { CostumersComponent } from './components/costumers/costumers.component';
import { EditCostumerComponent } from './components/costumers/edit-costumer/edit-costumer.component';
import { NewCostumerComponent } from './components/costumers/new-costumer/new-costumer.component';
import { CostumerInvoiceComponent } from './components/invoices-all/costumer-invoice/costumer-invoice.component';
import { InvoiceDetailComponent } from './components/invoices-all/invoice-detail/invoice-detail.component';
import { NewInvoiceComponent } from './components/invoices-all/new-invoice/new-invoice.component';
import { InvoicesComponent } from './components/invoices-all/invoices/invoices.component';
import { HomeComponent } from './components/home/home.component';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './components/navbar/navbar.component';
import { UsersComponent } from './components/users/users.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
  },
  {
    path: 'users',
    component: UsersComponent, canActivate:[AuthGuard]
  },
  {
    path: 'costumers',
    component: CostumersComponent, canActivate:[AuthGuard]
  },
  {
    path: 'invoices',
    component: InvoicesComponent, canActivate:[AuthGuard]
  },
  {
    path: 'new-costumer',
    component: NewCostumerComponent,
  },
  {
    path: 'edit-costumer/:id',
    component: EditCostumerComponent,
  },
  {
    path: 'invoices/:id',
    component: InvoiceDetailComponent,
  },
  {
    path: 'invoices/costumer/:id',
    component: CostumerInvoiceComponent,
  },
  {
    path: 'new-invoices/:id/:idCostumer',
    component: NewInvoiceComponent,
  },
  {
    path: '**',
    component: HomeComponent,
  },
];

@NgModule({
  declarations: [
    AppComponent,
    EditCostumerComponent,
    NewCostumerComponent,
    CostumerInvoiceComponent,
    InvoiceDetailComponent,
    NewInvoiceComponent,
    InvoicesComponent,
    HomeComponent,
    UsersComponent,
    NavbarComponent,
    CostumersComponent,
  ],
  imports: [
    BrowserModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    AuthRoutingModule,
    AuthModule,
    CommonModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
