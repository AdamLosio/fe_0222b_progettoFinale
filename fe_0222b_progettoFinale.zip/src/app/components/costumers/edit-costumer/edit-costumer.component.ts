import { Component, OnInit } from '@angular/core';
import { CostumersService } from '../../services/costumers.service';
import { GlobalService } from '../../services/global.service';
import { Clienti } from 'src/app/models/clienti';
import {FormGroup,FormBuilder,FormControl,Validators,} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Comune } from 'src/app/models/comuni';
import { Provincia } from 'src/app/models/provincia';

@Component({
  templateUrl: './edit-costumer.component.html',
  styleUrls: ['./edit-costumer.component.scss'],
})
export class EditCostumerComponent implements OnInit {
  cliente!: Clienti;
  form!: FormGroup;
  id!: number;
  province!: Provincia[];
  comuni!: Comune[];
  tipiclienti!: any[];

  constructor(
    private costumerSrv: CostumersService,
    private globalSrv: GlobalService,
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    console.log('ngOnInit');
    this.route.params.subscribe((params) => {
      this.id = +params['id'];
      console.log(this.id);
      this.InitializeForm();
    });
    this.InitializeForm();
    this.load();
  }

  InitializeForm() {
    this.form = this.fb.group({
      ragioneSociale: new FormControl('', [Validators.required]),
      partitaIva: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required]),
      tipoCliente: new FormControl('', [Validators.required]),
      pec: new FormControl(''),
      telefono: new FormControl(''),
      nomeContatto: new FormControl(''),
      cognomeContatto: new FormControl(''),
      telefonoContatto: new FormControl(''),
      emailContatto: new FormControl('', [Validators.required]),
      indirizzoSedeOperativa: this.fb.group({
        via: new FormControl(''),
        civico: new FormControl(''),
        cap: new FormControl(''),
        localita: new FormControl(''),
        comune: this.fb.group({
          id: new FormControl('', Validators.required),
          nome: '',
          provincia: {},
        }),
      }),
    });
  }

  load() {
    if (this.id !== 0) {
      this.costumerSrv.GetById(this.id).subscribe((data) => {
        console.log(data);
        this.cliente = data;
        this.form.patchValue({
          ragioneSociale: this.cliente.ragioneSociale,
          partitaIva: this.cliente.partitaIva,
          email: this.cliente.email,
          tipoCliente: this.cliente.tipoCliente,
          pec: this.cliente.pec,
          telefono: this.cliente.telefono,
          nomeContatto: this.cliente.nomeContatto,
          cognomeContatto: this.cliente.cognomeContatto,
          telefonoContatto: this.cliente.telefonoContatto,
          emailContatto: this.cliente.emailContatto,
          indirizzoSedeOperativa: {
            via: this.cliente.indirizzoSedeOperativa.via,
            civico: this.cliente.indirizzoSedeOperativa.civico,
            cap: this.cliente.indirizzoSedeOperativa.cap,
            localita: this.cliente.indirizzoSedeOperativa.localita,
          },
        });
      });
    }
    this.globalSrv
      .GetAllProvince(0)
      .subscribe((res) => (this.province = res.content));
    this.globalSrv
      .GetAllMunicipality(0)
      .subscribe((res) => (this.comuni = res.content));
    this.costumerSrv
      .GetCostumerType()
      .subscribe((res) => (this.tipiclienti = res));
  }
}
