import { Component, OnInit } from '@angular/core';
import { GlobalService } from '../services/global.service';
import { Clienti } from 'src/app/models/clienti';
import { Router } from '@angular/router';
import { CostumersService } from '../services/costumers.service';
import { InvoicesService } from '../services/invoices.service';
import { Fatture } from 'src/app/models/fatture';

@Component({
  templateUrl: './costumers.component.html',
  styleUrls: ['./costumers.component.scss'],
})
export class CostumersComponent implements OnInit {
  clienti!: Array<Clienti>;
  dettagli!: Fatture[];
  response: any;

  constructor(
    private globalSrv: GlobalService,
    private readonly router: Router,
    private costumersSrv: CostumersService,
    private invoicesSrv: InvoicesService
  ) {}

  ngOnInit(): void {
    this.globalSrv.getCostumers().subscribe((res) => {
      this.clienti = res.content;
      console.log(this.clienti);
    });
    this.load();
  }

  load() {
    this.costumersSrv.GetAll(0).subscribe((c) => {
      console.log(c);
      this.response = c;
      this.clienti = c.content;
    });
  }

  newCostumers() {
    this.router.navigate(['new-costumer']);
  }

  editCostumer(x: number) {
    this.costumersSrv.editCostumer(x).toPromise();

    this.router.navigate([`edit-costumer/${x}`]);
  }

  invoicesDetail(x: number) {
    this.invoicesSrv.detail(x).subscribe((res) => {
      this.dettagli = res.content;
      console.log(this.dettagli);
    });
  }

  changePages(p: number) {
    this.costumersSrv.GetAll(p).subscribe((c) => {
      console.log(c);
      this.response = c;
      this.clienti = c.content;
    });
  }

  counter(i: number) {
    return new Array(i);
  }

  confirmDelete(name: string, id: number, i: number) {
    if (confirm('Sei sicuro di voler eliminare il cliente ' + name + '?')) {
      console.log('Implement delete functionality here');
      this.costumersSrv.Delete(id).subscribe((c) => {
        console.log(c);
        this.clienti.splice(i, 1);
      });
    }
  }
}
