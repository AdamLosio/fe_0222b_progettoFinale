import { Component, OnInit } from '@angular/core';
import { CostumersService } from '../../services/costumers.service';
import { Clienti } from 'src/app/models/clienti';
import {FormGroup,FormBuilder,FormControl,Validators,} from '@angular/forms';
import { Router } from '@angular/router';
import { Comune } from 'src/app/models/comuni';
import { Provincia } from 'src/app/models/provincia';

@Component({
  templateUrl: './new-costumer.component.html',
  styleUrls: ['./new-costumer.component.scss'],
})
export class NewCostumerComponent implements OnInit {
  form!: FormGroup;
  user!: Clienti;
  comune!: Comune[];
  comuni!: any;
  provincia!: Provincia[];
  province!: any;

  constructor(
    private globalSrv: CostumersService,
    private router: Router,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.iniztializeForm();
    this.loadMunicipality();
    this.loadProvince();
  }

  regCostumer() {
    this.user = this.form.value;
    this.globalSrv.regCostumer(this.user).toPromise();
    alert('Nuovo cliente registrato!');
    this.router.navigate(['/clienti']);
    console.log(this.form.value);
  }

  loadMunicipality() {
    this.globalSrv.loadMunicipality().subscribe((res) => {
      this.comune = res.content;
    });
  }

  loadProvince() {
    this.globalSrv.loadProvince().subscribe((res) => {
      this.provincia = res.content;
    });
  }

  iniztializeForm() {
    this.form = this.fb.group({
      ragioneSociale: new FormControl('', [Validators.required]),
      partitaIva: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required]),
      tipoCliente: new FormControl('', [Validators.required]),
      pec: new FormControl(''),
      telefono: new FormControl(''),
      nomeContatto: new FormControl(''),
      cognomeContatto: new FormControl(''),
      telefonoContatto: new FormControl(''),
      emailContatto: new FormControl('', [Validators.required]),
      indirizzoSedeOperativa: this.fb.group({
        via: new FormControl(''),
        civico: new FormControl(''),
        cap: new FormControl(''),
        localita: new FormControl(''),
        comune: this.fb.group({
          id: new FormControl('', Validators.required),
          nome: '',
          provincia: {},
        }),
      }),
    });
  }
}
