import { Component, OnInit } from '@angular/core';
import { AuthService } from '../form/auth/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  isLoggend!:boolean

  constructor(private authSrv:AuthService) { }

  ngOnInit(): void {
    this.isLoggend=localStorage.getItem('user')!= null
  }
  UserLogged(): boolean{
    return localStorage.getItem('user') != null;
  }
  logout(){
    return this.authSrv.logout()
  }

}
