import { Injectable } from '@angular/core';
import { tap } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { Auth } from 'src/app/models/auth';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  Url = environment.pathApi;
  private authSubj = new BehaviorSubject<null | Auth>(null);
  user$ = this.authSubj.asObservable();
  out!: boolean;

  constructor(private http: HttpClient, private router: Router) {}

  login(data: { username: string; password: string }) {
    return this.http.post<Auth>(`${this.Url}/api/auth/login`, data).pipe(
      tap((data) => {
        console.log(data);
        this.authSubj.next(data);
        localStorage.setItem('user', JSON.stringify(data));
        this.out = true;
      })
    );
  }

  logout() {
    if (this.out) {
      confirm('Are you sure to Logout?');
      localStorage.removeItem('user');
      this.authSubj.next(null);
      this.router.navigate(['/']);
      this.out = false;
    }
  }

  createAccount(data: any) {
    return this.http.post(`${this.Url}/api/auth/signup`, data);
  }
}
