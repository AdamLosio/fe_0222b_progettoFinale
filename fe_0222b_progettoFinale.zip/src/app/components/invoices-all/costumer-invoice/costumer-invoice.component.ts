import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Fatture } from 'src/app/models/fatture';
import { InvoicesService } from '../../services/invoices.service';

@Component({
  templateUrl: './costumer-invoice.component.html',
  styleUrls: ['./costumer-invoice.component.scss'],
})
export class CostumerInvoiceComponent implements OnInit {
  idCliente!: number;
  page!: number;
  pageSize!: number;
  response: any;
  fatture!: Fatture[];

  constructor(
    private invoicesSrv: InvoicesService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.idCliente = +params['id'];
      console.log(this.idCliente);
      this.load();
    });
  }

  load() {
    if (this.idCliente) {
      this.invoicesSrv.GetByCostumer(this.idCliente, 0).subscribe((c) => {
        console.log(c);
        this.response = c;
        this.fatture = c.content;
      });
    } else {
      this.invoicesSrv.GetAll(0).subscribe((c) => {
        console.log(c);
        this.response = c;
        this.fatture = c.content;
      });
    }
  }

  changePages(p: number) {
    if (this.idCliente) {
      this.invoicesSrv.GetByCostumer(this.idCliente, p).subscribe((c) => {
        console.log(c);
        this.response = c;
        this.fatture = c.content;
      });
    } else {
      this.invoicesSrv.GetAll(p).subscribe((c) => {
        console.log(c);
        this.response = c;
        this.fatture = c.content;
      });
    }
  }

  counter(i: number) {
    return new Array(i);
  }

  confirmDelete(name: number, id: number, i: number) {
    if (
      confirm('Sei sicuro di voler cancellare la fattura numero ' + name + '?')
    ) {
      console.log('Implement delete functionality here');
      this.invoicesSrv.Delete(id).subscribe((c) => {
        console.log(c);
        this.fatture.splice(i, 1);
      });
    }
  }
}
