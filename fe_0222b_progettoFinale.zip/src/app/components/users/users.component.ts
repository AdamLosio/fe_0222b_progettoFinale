import { Component, OnInit } from '@angular/core';
import { Auth } from 'src/app/models/auth';
import { GlobalService } from '../services/global.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
})
export class UsersComponent implements OnInit {
  page!: number;
  pageSize!: number;
  response: any;
  users!: Array<Auth>;

  constructor(private globalSrv: GlobalService) {}

  ngOnInit() {
    this.Load();
  }

  Load() {
    this.globalSrv.GetAll(0).subscribe((c) => {
      console.log(c);
      this.response = c;
      this.users = c.content;
    });
  }

  ChangePage(p: number) {
    this.globalSrv.GetAll(p).subscribe((res) => {
      this.response = res;
      this.users = res.content;
    });
  }

  counter(i: number) {
    return new Array(i);
  }
}
