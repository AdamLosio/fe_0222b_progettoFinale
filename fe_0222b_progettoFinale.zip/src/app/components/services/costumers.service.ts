import { Injectable, NgModule } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class CostumersService {
  Url = environment.pathApi;
  form: any;
  utenteMod: any;

  constructor(private http: HttpClient) {}

  loadMunicipality() {
    return this.http.get<any>(
      `${this.Url}/api/comuni?page=0&size=20&sort=id,ASC`
    );
  }

  loadProvince() {
    return this.http.get<any>(
      `${this.Url}/api/province?page=0&size=20&sort=id,ASC`
    );
  }

  regCostumer(data: any) {
    return this.http.post<any>(`${this.Url}/api/clienti`, data);
  }

  editCostumer(data: number) {
    return this.http.get<any>(`${this.Url}/api/clienti/${data}`);
  }

  GetAll(p: number) {
    return this.http.get<any>(
      this.Url + '/api/clienti?page=' + p + '&size=20&sort=id,ASC'
    );
  }

  GetById(ID: number) {
    return this.http.get<any>(this.Url + '/api/clienti/' + ID);
  }

  Delete(id: number) {
    return this.http.delete<boolean>(this.Url + '/api/clienti/' + id);
  }

  GetCostumerType() {
    return this.http.get<any>(this.Url + '/api/clienti/tipicliente');
  }
}
