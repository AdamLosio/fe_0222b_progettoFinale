import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  Url = environment.pathApi;

  constructor(private http: HttpClient) {}

  getUsers() {
    return this.http.get<any>(`${this.Url}/api/users`);
  }

  getCostumers() {
    return this.http.get<any>(
      `${this.Url}/api/clienti?page=0&size=20&sort=id,ASC`
    );
  }

  getInvoices() {
    return this.http.get<any>(
      `${this.Url}/api/fatture?page=0&size=20&sort=id,ASC`
    );
  }

  GetAll(p: number) {
    console.log('getall');
    return this.http.get<any>(
      this.Url + '/api/users?page=' + p + '&size=20&sort=id,ASC'
    );
  }

  GetAllProvince(p: number) {
    return this.http.get<any>(
      this.Url + '/api/province?page=' + p + '&size=20&sort=id,ASC'
    );
  }

  GetAllMunicipality(p: number) {
    return this.http.get<any>(
      this.Url + '/api/comuni?page=' + p + '&size=20&sort=id,ASC'
    );
  }
}
