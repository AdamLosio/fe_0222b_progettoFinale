import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class InvoicesService {
  Url = environment.pathApi;

  constructor(private http: HttpClient) {}

  deleteInvoices() {
    return this.http.delete(`${this.Url}/api/fatture/cliente/3`);
  }

  detail(id: number) {
    return this.http.get<any>(
      `${this.Url}/api/fatture/cliente/${id}?page=0&size=20&sort=id,ASC`
    );
  }

  GetByCostumer(ID: number, p: number) {
    return this.http.get<any>(
      this.Url +
        '/api/fatture/cliente/' +
        ID +
        '?page=' +
        p +
        '&size=20&sort=id,ASC'
    );
  }

  GetAll(p: number) {
    return this.http.get<any>(
      this.Url + '/api/fatture?page=' + p + '&size=20&sort=id,ASC'
    );
  }

  Delete(id: number) {
    return this.http.delete<boolean>(this.Url + '/api/fatture/' + id);
  }

  GetAllStatus(p: number) {
    return this.http.get<any>(
      this.Url + '/api/statifattura?page=' + p + '&size=20&sort=id,ASC'
    );
  }

  GetById(ID: number) {
    return this.http.get<any>(this.Url + '/api/fatture/' + ID);
  }

  Save(id: number, item: any) {
    if (id === 0) {
      return this.http.post<any>(this.Url + '/api/fatture', item);
    } else {
      return this.http.put<any>(this.Url + '/api/fatture/' + id, item);
    }
  }
}
