export class StatoFattura {
  id!: number;
  nome!: string;
}
